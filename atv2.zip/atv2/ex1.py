# Solicitar ao usuário os valores dos lados do retângulo
lado1 = float(input("Digite o valor do primeiro lado (base) do retângulo: "))
lado2 = float(input("Digite o valor do segundo lado (altura) do retângulo: "))

# Calcular o perímetro e a área
perimetro = 2 * (lado1 + lado2)
area = lado1 * lado2

# Exibir os resultados
print(f"O perímetro do retângulo é: {perimetro}")
print(f"A área do retângulo é: {area}")
