import math

# Solicitar ao usuário os coeficientes a, b e c
a = float(input("Digite o valor de a: "))
b = float(input("Digite o valor de b: "))
c = float(input("Digite o valor de c: "))

# Calcular o discriminante (delta)
delta = b**2 - 4*a*c

# Verificar se delta é maior ou igual a 0 para garantir que as raízes são reais
if delta >= 0:
    # Calcular as duas raízes usando a fórmula quadrática
    x1 = (-b + math.sqrt(delta)) / (2 * a)
    x2 = (-b - math.sqrt(delta)) / (2 * a)

    # Exibir as raízes
    print(f"As raízes da equação são: X1 = {x1} e X2 = {x2}")
else:
    print("Não existem raízes reais para esta equação.")
